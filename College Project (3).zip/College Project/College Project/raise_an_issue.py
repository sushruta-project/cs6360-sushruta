
from tkinter import *
import tkinter as tk
from tkinter import ttk, messagebox
import pymysql
import customtkinter


# start Signup Window	

customtkinter.set_appearance_mode("dark")  # Modes: system (default), light, dark
customtkinter.set_default_color_theme("dark-blue")  # Themes: blue (default), dark-blue, green

winsignup = customtkinter.CTk()
winsignup.title("Sushruta - Raise an Issue")
winsignup.maxsize(width=750 ,  height=300)
winsignup.minsize(width=750 ,  height=300)

heading = customtkinter.CTkButton(winsignup , text = "Raise an Issue")
heading.place(x=250 , y=90)

back_button = customtkinter.CTkButton(winsignup , text="MY PROFILE")# command = switch )
back_button.place(x=250 , y =20)

logout_btn = customtkinter.CTkButton(winsignup , text="LOGOUT")#command = switch )
logout_btn.place(x=550 , y =20)

my_schedule = customtkinter.CTkButton(winsignup , text="MY SCHEDULE")#command = switch )
my_schedule.place(x=100 , y =20)

rai = customtkinter.CTkButton(winsignup , text="RAISE AN ISSUE")#command = switch )
rai.place(x=400 , y =20)

# Entry Box ------------------------------------------------------------------

description= StringVar()

d1 = Entry(winsignup, width=40 , textvariable = description)
d1.place(x=250 , y=165)

submit  = customtkinter.CTkButton(winsignup, text = "SUBMIT" )#command = action)
submit.place(x=250, y=175)

winsignup.mainloop()