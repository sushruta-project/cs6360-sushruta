import curses
from tkinter import *
import tkinter as tk
from tkinter import ttk, messagebox
import pymysql
import customtkinter
import os, sys

class Frontpage:
    def whatIsIt(self):
        whatWindow = Tk()
        whatWindow.maxsize(width=750 ,  height=750)
        whatWindow.minsize(width=750 ,  height=750)
        whatWindow.title("Sushruta - Main Page")
        
        self.titleLabel = Label(whatWindow, text="Sushruta - Medicare For All ", font=('verdana 25 bold'), fg='black')
        self.titleLabel.place(x=100, y=150)

        self.details = Label(whatWindow, text="Sushruta is an easy to use Telemedicine Website. It integrates Patient, Doctor & Pharamcist into 1 umbrella. It eliminates the time redundacy by the patient to ask to each & every indiviudual pharmacy regarding medicine availability or not.",\
                    font=('verdana 20'), fg='black', wraplength=500, justify='center')
        self.details.place(x=100, y=200)
        
        btn1= customtkinter.CTkButton(whatWindow, text = "Patient Login", width = 20, command = lambda: self.patientLogin())
        btn1.place(x=100, y=100)

        btn2= customtkinter.CTkButton(whatWindow, text = "Doctors Login", width = 20, command = lambda: self.doctorLogin())
        btn2.place(x=200, y=100)
        
        btn3= customtkinter.CTkButton(whatWindow, text = "Pharmacy Login", width = 20, command = lambda: self.pharmacyLogin())
        btn3.place(x=300, y=100)
        
        btn4= customtkinter.CTkButton(whatWindow, text = "Adminitrator Login ", width = 20, command = lambda: self.adminLogin())
        btn4.place(x=415, y=100)

        whatWindow.mainloop()

    def patientLogin(self):
        if sys.platform.startswith('Linux'):
            os.system("python3 main_modified.py")
        elif sys.platform.startswith('win32'):
            os.system("python main_modified.py")
    
    #TODO
    def doctorLogin(self):
        if sys.platform.startswith('Linux'):
            os.system("python3 docter.py")
        elif sys.platform.startswith('win32'):
            os.system("python docter.py")

    def pharmacyLogin(self):
        if sys.platform.startswith('Linux'):
            os.system("python3 pharmacy.py")
        elif sys.platform.startswith('win32'):
            os.system("python pharmacy.py")
    
    def adminLogin(self):
        if sys.platform.startswith('Linux'):
            os.system("python3 raise_an_issue.py")
        elif sys.platform.startswith('win32'):
            os.system("python raise_an_issue.py")	

f = Frontpage()
f.whatIsIt()
