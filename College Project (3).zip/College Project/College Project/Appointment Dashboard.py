
from tkinter import *
import tkinter as tk
from tkinter import ttk, messagebox
import pymysql
import customtkinter


# start Signup Window	

customtkinter.set_appearance_mode("dark")  # Modes: system (default), light, dark
customtkinter.set_default_color_theme("blue")  # Themes: blue (default), dark-blue, green

winsignup = customtkinter.CTk()
winsignup.title("Sushruta - Appointment Dashboard")
winsignup.maxsize(width=750 ,  height=750)
winsignup.minsize(width=750 ,  height=750)

heading = customtkinter.CTkButton(winsignup , text = "Appointment Dashboard")
heading.place(x=80 , y=90)

back_button = customtkinter.CTkButton(winsignup , text="MY PROFILE")# command = switch )
back_button.place(x=250 , y =20)

logout_btn = customtkinter.CTkButton(winsignup , text="LOGOUT")#command = switch )
logout_btn.place(x=550 , y =20)

my_schedule = customtkinter.CTkButton(winsignup , text="MY SCHEDULE")#command = switch )
my_schedule.place(x=100 , y =20)

rai = customtkinter.CTkButton(winsignup , text="RAISE AN ISSUE")#command = switch )
rai.place(x=400 , y =20)

# form data label

heading_2 = customtkinter.CTkButton(winsignup , text = "Past Appointments")
heading_2.place(x=80 , y=400)

	# Entry Box ------------------------------------------------------------------

accept = customtkinter.CTkButton(winsignup, text = "ACCEPT" )#command = action)
accept.place(x=150, y=600)
	
cancel = customtkinter.CTkButton(winsignup, text = "CANCEL" ) #command = clear)
cancel.place(x=350, y=600)

winsignup.mainloop()