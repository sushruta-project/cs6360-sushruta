USE SHUSHRUT;
SELECT * FROM PHARMACY;
SELECT * FROM MEDICINE;
SELECT * FROM AVAILABILITY;

select * from doctor;

update patient set username = 'kate', password = '123' where id = 3;

ALTER TABLE doctor ADD COLUMN username varchar(225) NOT NULL DEFAULT("root");

ALTER TABLE doctor ADD COLUMN password  Varchar(10) NOT NULL DEFAULT("root");

alter table patient modify id int auto_increment;

alter table patient ADD COLUMN username varchar(50) NOT NULL DEFAULT("root");

alter table patient ADD COLUMN password varchar(50) NOT NULL DEFAULT("root");

insert into appointment values (1, 1, '2022-08-14', 'Completed', '70$', 8, 'professional and understanding.explained conditions well', 'continue medicine for 3 days until condition improves');

insert into appointment values (2, 3, '2022-07-17', 'Completed', '120$', 7.5, 'listened and answered patiently', 'continue medicine for 1 week. avoid stress');

insert into appointment values (2, 5, '2022-10-05', 'Completed', '85$', 9, 'careful doctor', 'continue medicine for 4 days. revert if condition worsens');

insert into appointment values (7, 9, '2022-08-20', 'Completed', '30$', 4.5, 'prepared and very organized and really made taking care of me a priority', 'continue medicine for 3 days. revert if condition worsens');

insert into appointment values (3, 4, '2022-09-01', 'Completed', '80$', 8, 'excellent doctor', 'continue medicine for 2 weeks. light exercise');

insert into appointment values (9, 3, '2022-07-17', 'Completed', '120$', 7.5, 'appointment was not rushed', 'continue medicine for 1 week. revert if condition worsens');

insert into appointment values (4, 1, '2022-11-11', 'Completed', '70$', 8, 'listened and answered patiently', 'continue medicine for 3 days until condition improves');

insert into appointment values (10, 7, '2022-06-10', 'Completed', '80$', 6, 'no waiting time. friendly and knowledgable', 'continue medicine for 2 weeks. light exercise');

insert into appointment values (8, 6, '2022-10-19', 'Completed', '160$', 8.5, 'friendly and knowledgable. excellent suggestions', 'continue medicine for 2 weeks. revert if condition worsens');

insert into appointment values (5, 3, '2022-09-01', 'Completed', '120$', 7.5, 'friendly and knowledgable. excellent suggestions', 'continue medicine for 1 week. light exrcise. avoid stress');

insert into appointment values (7, 6, '2022-11-24', 'Upcoming', '160$', null, null, null);

alter table appointment modify patient_feedback varchar(100);

select * from appointment;

select * from appointment 

select * from medicine;

select * from pharmacy

select * from availability

select * from doctor;

use shushrut;
alter table appointment add column modified_date date null;