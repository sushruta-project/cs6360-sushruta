import curses
from tkinter import *
import tkinter as tk
from tkinter import ttk, messagebox
import pymysql
import customtkinter

#---------------------------------------------------------------Login Function --------------------------------------
def clear():
	userentry.delete(0,END)
	passentry.delete(0,END)

def close():
	win.destroy()	


def login():
  
	if store_name.get()=="" or password.get()=="":
		messagebox.showerror("Error","Enter User Name And Password",parent=win)	
	else:
		try:
			con = pymysql.connect(host="localhost",user="root",password="123456",database="shushrut")
			cur = con.cursor()
			cur.execute("select * from pharmacy where store_name=%s and password = %s",(store_name.get(),password.get()))
			row = cur.fetchone()

			if row==None:
				messagebox.showerror("Error" , "Invalid Store Name And Password", parent = win)

			else:
				messagebox.showinfo("Success" , "Successfully Login" , parent = win)
				close()
				deshboard()
			con.close()
		except Exception as es:
			messagebox.showerror("Error" , f"Error Due to : {str(es)}", parent = win)

#---------------------------------------------------------------End Login Function ---------------------------------
#------------------------------------------------------------------Logout---------------------------------------------------------------
# function to close the top window
def logout(parent):
	MsgBox = tk.messagebox.askquestion('Logout Application','Are you sure you want to logout?', icon='warning')
	if MsgBox == 'yes':
	# self.path = self.name + ".jpg"
		print("parent is ", parent)
		parent.destroy()
		login()

#---------------------------------------------------- DashBoard Panel -----------------------------------------
def deshboard():

	def unavailable():
		des = Tk()
		des.title(store_name.get())	
		des.maxsize(width=800 ,  height=800)
		des.minsize(width=800 ,  height=800)	
		f=Frame(des,height=1,width=800)
		f.place(x=95,y=95)
		con = pymysql.connect(host="localhost",user="root",password="123456",database="shushrut")
		cur2 = con.cursor()
		cur2.execute("select name from availability natural join medicine where store_id = (select store_id from pharmacy where store_name = 'Abrams Pharmacy') and count=0;")
		row2 = cur2.fetchall()
		heading = Label(des , text = "Unavailable Medicines" , font = 'Verdana 25 bold',)
		heading.place(x=100 , y=50)
		for ind, data in enumerate(row2,1): 
		
			med_name = customtkinter.CTkButton(des, text= f"medicine Name : {data[0]}")
			med_name.place(x=20,y=100*ind)


	def add_inventory():
		def add_med():
			print(med_name1.get(),count1.get(),price1.get())
			if med_name1.get() =="" or count1.get() =="" or price1.get() == "" :
				messagebox.showerror("Error" , "All Fields Are Required" , parent = des1)

			else:
				con = pymysql.connect(host="localhost",user="root",password="123456",database="shushrut")
				cur = con.cursor()

				cur.execute("select store_id from pharmacy where store_name = %s",(store_name.get()))
				store_id = cur.fetchall()[0][0]
				print(store_id)
				cur.execute("select medicine_id from medicine where name = %s", (med_name1.get()))
				medicine_id = cur.fetchall()[0][0]
				print(medicine_id)
				cur.execute("insert into availability (medicine_id, store_id, availability, count, price) VALUES (%s,%s,%s,%s,%s)",
							(medicine_id, 
							store_id,
							1,
							count1.get(),
							price1.get()
							))
				con.commit()
				messagebox.showinfo("Success" , "Add" , parent = des1)

		des1 = Tk()
		des1.title('Pharmacy - Add a Medicine')
		des1.maxsize(width=800 ,  height=800)
		des1.minsize(width=800 ,  height=800)	

		#heading label
		heading = Label(des1 , text = 'Add a Medicine' , font = 'Verdana 20 bold')
		heading.place(x=220 , y=50)

		f=Frame(des1,height=1,width=800,bg="black")
		f.place(x=0,y=95)

		med_name = StringVar()
		count = StringVar()
		price = StringVar()
	
		med_name1 = Entry(des1, width=40 , textvariable = med_name)
		med_name1.place(x=250 , y=135)
	
		count1 = Entry(des1, width=40 , textvariable = count)
		count1.place(x=250 , y=165)

		price1 = Entry(des1, width=40, textvariable = price)
		price1.place(x=250 , y=195)

		Mname = Label(des1, text= "Medicine Name :" , font='Verdana 10 bold')
		Mname.place(x=80,y=135)

		C = Label(des1, text= "Count :" , font='Verdana 10 bold')
		C.place(x=80,y=165)

		P = Label(des1, text= " Price :" , font='Verdana 10 bold')
		P.place(x=80,y=195)

		btn_signup = customtkinter.CTkButton(des1, text = "ADD", command = add_med)
		btn_signup.place(x=200, y=300)
		des1.mainloop() 	

	des = Tk()
	des.title(store_name.get())
	des.maxsize(width=800 ,  height=800)
	des.minsize(width=800 ,  height=800)		

# menu bar
	Chooser = Menu()
	Chooser.add_cascade(label='Raise an Issue')
	Chooser.add_cascade(label='Logout', command=lambda: logout(des))	

	des.config(menu=Chooser)


	#heading label
	heading = Label(des , text = f"{store_name.get()}" , font = 'Verdana 20 bold',)
	heading.place(x=220 , y=50)

	f=Frame(des,height=1,width=800,bg="black")
	f.place(x=0,y=95)

	con = pymysql.connect(host="localhost",user="root",password="123456",database="shushrut")
	cur1 = con.cursor()
	cur1.execute("select name, count, price from availability natural join medicine where store_id = (select store_id from pharmacy where store_name = %s) and count>0;",(store_name.get()))
	row1 = cur1.fetchall()

	for ind, data in enumerate(row1,2): 
    
		med_name = customtkinter.CTkButton(des, text= f"Medicine Name : {data[0]}" )
		med_name.place(x=20,y=50*ind) 
		count = customtkinter.CTkButton(des, text= f"Available Count : {data[1]}")
		count.place(x=200,y=50*ind)
		price = customtkinter.CTkButton(des, text= f"Price of the Medicine : {data[2]}")
		price.place(x=350,y=50*ind)
	
	# button 
	btn1= customtkinter.CTkButton(des, text = "Unavailable Medicines" , width = 20, command= unavailable)
	btn1.place(x=600, y=200)
	# # Book Docter Entry Box
	btn2= customtkinter.CTkButton(des, text = "Add Inventory" , width = 20, command=add_inventory)
	btn2.place(x=600, y=150)

					
#-----------------------------------------------------End Deshboard Panel -------------------------------------
#----------------------------------------------------------- Signup Window --------------------------------------------------

def signup():
	# signup database connect 
	def action():
		if phar_name.get()=="" or phar_zipcode.get()=="" or password.get()=="" or very_pass.get()=="":
			messagebox.showerror("Error" , "All Fields Are Required" , parent = winsignup)
		elif password.get() != very_pass.get():
			messagebox.showerror("Error" , "Password & Confirm Password Should Be Same" , parent = winsignup)
		else:
			try:
				con = pymysql.connect(host="localhost",user="root",password="123456",database="shushrut")
				cur = con.cursor()
				cur.execute("select * from pharmacy where store_name=%s",store_name.get())
				row = cur.fetchone()
				if row!=None:
					messagebox.showerror("Error" , "User Name Already Exits", parent = winsignup)
				else:
					cur.execute("insert into pharmacy(store_name,location,password) values(%s,%s,%s)",
						(
						phar_name.get(),
						phar_zipcode.get(),
						password.get()
						))
					con.commit()
					con.close()
					messagebox.showinfo("Success" , "Registration Successful" , parent = winsignup)
					clear()
					switch()
				
			except Exception as es:
				messagebox.showerror("Error" , f"Error Dui to : {str(es)}", parent = winsignup)

	# close signup function			
	def switch():
		winsignup.destroy()

	# clear data function
	def clear():
		phar_name.delete(0,END)
		phar_zipcode.delete(0,END)
		password.delete(0,END)
		very_pass.delete(0,END)

	# start Signup Window	

	winsignup = Tk()
	winsignup.title("Sushruta - Pharmacy Signup")
	winsignup.maxsize(width=750 ,  height=750)
	winsignup.minsize(width=750 ,  height=750)

	#heading label
	heading = Label(winsignup , text = "Pharmacy Signup",font = 'Verdana 25 bold')
	heading.place(x=80 , y=60)

	# form data label
	phar_name = customtkinter.CTkButton(winsignup, text= "Name :" )
	phar_name.place(x=80,y=130)

	phar_zipcode = customtkinter.CTkButton(winsignup, text= "Zipcode:")
	phar_zipcode.place(x=80,y=160)

	password = customtkinter.CTkButton(winsignup, text= "Password :")
	password.place(x=80,y=190)

	very_pass = customtkinter.CTkButton(winsignup, text= "Verify Password:")
	very_pass.place(x=80,y=220)

	# Entry Box ------------------------------------------------------------------

	phar_name = StringVar()
	phar_zipcode = StringVar()
	password = StringVar()
	very_pass = StringVar()

	phar_name = Entry(winsignup, width=40 , textvariable = phar_name)
	phar_name.place(x=250 , y=135)
	
	phar_zipcode = Entry(winsignup, width=40 , textvariable = phar_zipcode)
	phar_zipcode.place(x=250 , y=165)

	password = Entry(winsignup, width=40, textvariable = password)
	password.place(x=250 , y=195)

	very_pass= Entry(winsignup, width=40 ,show="*" , textvariable = very_pass)
	very_pass.place(x=250 , y=230)

	# button login and clear

	btn_signup = customtkinter.CTkButton(winsignup, text = "SIGN UP", command = action)
	btn_signup.place(x=200, y=300)

	btn_login = customtkinter.CTkButton(winsignup, text = "CLEAR" , command = clear)
	btn_login.place(x=350, y=300)

	sign_up_btn = customtkinter.CTkButton(winsignup , text="SWITCH TO LOGIN PAGE" , command = switch )
	sign_up_btn.place(x=350 , y=20)

	winsignup.mainloop()
#---------------------------------------------------------------------------End Singup Window-----------------------------------	

#------------------------------------------------------------ Login Window -----------------------------------------

win = Tk()

# app title
win.title("Shushruta - Pharmacist Login Page")

# window size
win.maxsize(width=750 ,  height=750)
win.minsize(width=750 ,  height=750)


#heading label
heading = Label(win , text = "Pharmacy Login" , font = 'Verdana 25 bold')
heading.place(x=80 , y=150)

store_name = customtkinter.CTkButton(win, text= "Store Name :")
store_name.place(x=80,y=220)

userpass = customtkinter.CTkButton(win, text= "Password :")
userpass.place(x=80,y=260)

# Entry Box
store_name = StringVar()
password = StringVar()
	
userentry = Entry(win, width=40 , textvariable = store_name)
userentry.focus()
userentry.place(x=250 , y=223)

passentry = Entry(win, width=40, show="*" ,textvariable = password)
passentry.place(x=250 , y=260)

# button login and clear

btn_login = customtkinter.CTkButton(win, text = "LOGIN",command = login)
btn_login.place(x=200, y=293)

btn_login = customtkinter.CTkButton(win, text = "CLEAR", command = clear)
btn_login.place(x=350, y=293)

# signup button

sign_up_btn = customtkinter.CTkButton(win , text="SWITCH TO LOGIN PAGE" , command = signup )
sign_up_btn.place(x=350 , y =20)

win.mainloop()

#-------------------------------------------------------------------------- End Login Window ---------------------------------------------------