
# Import required libraries
from tkinter import *
from PIL import ImageTk, Image

# Create an instance of tkinter window
win = Tk()
win.title('Sushruta Front Page')

# Define the geometry of the window
win.geometry("700x500")

frame = Frame(win, width=500, height=500)
frame.pack()
frame.place(anchor='se', relx=0.5, rely=0.5)

# Create an object of tkinter ImageTk
img = ImageTk.PhotoImage(Image.open("C:\\Users\\USS220000\\Desktop\\College Project\\Sushruta-1.jpg"))

# Create a Label Widget to display the text or Image
label = Label(frame, image = img)
label.pack()

###########Adding the Text##################################

T = Text(win, height = 10, width = 10, font =("ARIAL", 14))

# Create label
l = Label(win, text = "WELCOME TO SUSHRUTA MEDICARE FOR ALL")
l.config(font =("ARIAL", 14))

Fact = "A man can be arrested in Italy for wearing a skirt in public."
T.insert(INSERT, "Write Something About Yourself")


l.pack()
T.pack()

win.mainloop()