import curses
from tkinter import *
import tkinter as tk
from tkinter import ttk, messagebox
import pymysql
import customtkinter


#---------------------------------------------------------------Login Function --------------------------------------
class Table:
		
	def __init__(self,root, data):
		total_rows = len(data)
		total_columns = len(data[0])

		for i in range(total_rows):
			for j in range(total_columns):
				
				self.e = Entry(root, width=20, fg='black',
								font=('Arial',16,'bold'))

				self.e.grid(row=i, column=j)
				self.e.insert(END, data[i][j])

def clear():
	userentry.delete(0,END)
	passentry.delete(0,END)

def close():
	win.destroy()	

def login():
  
	if username.get()=="" or password.get()=="":
		messagebox.showerror("Error","Enter User Name And Password",parent=win)	
	else:
		try:
			con = pymysql.connect(host="localhost",user="root",password="123456",database="shushrut")
			cur = con.cursor()
			cur.execute("select * from doctor where username=%s and password = %s",(username.get(),password.get()))
			row = cur.fetchone()

			if row==None:
				messagebox.showerror("Error" , "Invalid username or Password", parent = win)

			else:
				messagebox.showinfo("Success" , "Successfully Login" , parent = win)
				close()
				deshboard()
			con.close()
		except Exception as es:
			messagebox.showerror("Error" , f"Error Due to : {str(es)}", parent = win)

#---------------------------------------------------------------End Login Function ---------------------------------
#------------------------------------------------------------------Logout---------------------------------------------------------------
# function to close the top window
def logout(parent):
	MsgBox = tk.messagebox.askquestion('Logout Application','Are you sure you want to logout?', icon='warning')
	if MsgBox == 'yes':
	# self.path = self.name + ".jpg"
		print("parent is ", parent)
		parent.destroy()
		login()


#---------------------------------------------------- DashBoard Panel -----------------------------------------
def deshboard():	

	def upcoming():
		root = Tk()
		root.maxsize(width=1500 ,  height=200)
		root.minsize(width=1500 ,  height=200)
		cur1.execute("Select p.first_name, A.date_time,A.patient_feedback,A.doctor_comments,A.rating_by_patient from  Appointment A  join  patient p where A.status = 'upcoming' and p.id = A.patient_id and A.doctor_id =(Select doctor_id from doctor D where D.first_name = %s);",(username.get()))
		data = cur1.fetchall()
		data = [("Patient Name", "Date Time","patient_feedback","doctor_comments",),
		('Raj','Nov 21, 2022 Mon 10 AM - 11 AM ','listened and answered patiently ','take crocin for 5 days' ),
		('James','Nov 11, 2022 Mon 10 AM - 11 AM ','Fever, vomiting','continue medicine for 2 weeks. revert if condition worsens') ]
		print(data)
		Table(root,data)
		root.mainloop()
	def completed():
		root = Tk()
		root.maxsize(width=1500 ,  height=200)
		root.minsize(width=1500 ,  height=200)
	
		cur1.execute("Select p.first_name, A.date_time,A.patient_feedback,A.doctor_comments,A.rating_by_patient from  Appointment A  join  patient p where A.status = 'completed' and p.id = A.patient_id and A.doctor_id =(Select doctor_id from doctor D where D.first_name = 'John');")
		data = cur1.fetchall()
		data = [("Patient Name", "Date Time","patient_feedback","doctor_comments"),
		('Aryan','Dec 15, 2022 Mon 10 AM - 11 AM ','NA') ]
		Table(root,data)
		root.mainloop()
	des = Tk()
	des.title(username.get())
	des.maxsize(width=1000 ,  height=800)
	des.minsize(width=1000 ,  height=800)	

	# menu bar
	Chooser = Menu()
	Chooser.add_cascade(label='Raise an Issue')
	Chooser.add_cascade(label='Logout', command=lambda: logout(des))	

	des.config(menu=Chooser)

	#heading label
	heading = Label(des , text = f"{username.get()}" , font = 'Verdana 20 bold',)
	heading.place(x=220 , y=50)

	f=Frame(des,height=1,width=1000,bg="black")
	f.place(x=0,y=95)

	con = pymysql.connect(host="localhost",user="root",password="123456",database="shushrut")
	cur1 = con.cursor()
	cur1.execute("select first_name, last_name, specialization, year_of_experience, fee from doctor where first_name = 'mark' ")
	data = cur1.fetchall()[0]
	print(data)
	f_name = Label(des, text= f"{data[0]}" )
	f_name.place(x=80,y=130)

	l_name = Label(des, text= f"{data[1]}" )
	l_name.place(x=180,y=130)

	specialization = Label(des, text= f"Specialization : '{data[2]}'" )
	specialization.place(x=80,y=150)

	yoe = Label(des, text= f"Years of Experience : {data[3]}" )
	yoe.place(x=80,y=170)

	availability = Label(des, text= "Timings: Mon- Fri 8:00 AM - 12:00 PM" )
	availability.place(x=80,y=190)

	fee = Label(des, text= f"Fee :${data[4]}" )
	fee.place(x=80,y=210)
	

	btn1= customtkinter.CTkButton(des, text = " Show past appointments " , width = 20, command = completed)
	btn1.place(x=600, y=200)
	# # Book Docter Entry Box
	btn2= customtkinter.CTkButton(des, text = "Show Upcoming appointments" , width = 20, command = upcoming)
	btn2.place(x=600, y=150)

					
#-----------------------------------------------------End Deshboard Panel -------------------------------------
#----------------------------------------------------------- Signup Window --------------------------------------------------

def signup():
	# signup database connect 
	def action():
		if password.get() != very_pass.get():
			messagebox.showerror("Error" , "Password & Confirm Password Should Be Same" , parent = winsignup)
		else:
			try:
				con = pymysql.connect(host="localhost",user="root",password="123456",database="shushrut")
				cur = con.cursor()
				cur.execute("select * from doctor where username=%s",username.get())
				row = cur.fetchone()
				if row!=None:
					messagebox.showerror("Error" , "User Name Already Exits", parent = winsignup)
				else:
					cur.execute("insert into doctor(first_name, last_name, specialization, availability, year_of_experience, fee, username, password) values(%s,%s,%s,%s,%s,%s,%s,%s)",
						(
						f_name.get(),
						l_name.get(),
						specialization.get(),
						'1',
						yoe.get(),
						fee.get(),
						username.get(),
						password.get()
						))
					con.commit()
					con.close()
					messagebox.showinfo("Success" , "Registration Successful" , parent = winsignup)
					switch()
				
			except Exception as es:
				messagebox.showerror("Error" , f"Error Dui to : {str(es)}", parent = winsignup)

	# close signup function			
	def switch():
		winsignup.destroy()

	# clear data function


	# start Signup Window	

	winsignup = Tk()
	winsignup.title("Sushruta - Docter Signup")
	winsignup.maxsize(width=750 ,  height=750)
	winsignup.minsize(width=750 ,  height=750)

	#heading label
	heading = Label(winsignup , text = "Docter Signup",font = 'Verdana 25 bold')
	heading.place(x=80 , y=60)

	# form data label
	f_name = Label(winsignup, text= "First Name :" )
	f_name.place(x=80,y=130)

	l_name = Label(winsignup, text= "Last Name :" )
	l_name.place(x=80,y=150)

	specialization = Label(winsignup, text= "Specialization :" )
	specialization.place(x=80,y=170)

	availability = Label(winsignup, text= "Availability :" )
	availability.place(x=80,y=190)

	yoe = Label(winsignup, text= "Years of Experience :" )
	yoe.place(x=80,y=210)

	fee = Label(winsignup, text= "Fee :" )
	fee.place(x=80,y=230)

	username = Label(winsignup, text= "UserName :" )
	username.place(x=80,y=250)

	password = Label(winsignup, text= "Password :")
	password.place(x=80,y=270)

	very_pass = Label(winsignup, text= "Verify Password:")
	very_pass.place(x=80,y=290)

	# Entry Box ------------------------------------------------------------------

	f_name = StringVar()
	l_name = StringVar()
	specialization = StringVar()
	availability = StringVar()
	yoe = StringVar()
	fee=StringVar()
	username=StringVar()
	password=StringVar()
	ver_password=StringVar()

	f_name = Entry(winsignup, width=40 , textvariable = f_name)
	f_name.place(x=250 , y=130)

	l_name = Entry(winsignup, width=40 , textvariable = l_name)
	l_name.place(x=250 , y=150)

	specialization = Entry(winsignup, width=40 , textvariable = specialization)
	specialization.place(x=250 , y=170)

	availability = Entry(winsignup, width=40 , textvariable = availability)
	availability.place(x=250 , y=190)

	yoe = Entry(winsignup, width=40 , textvariable = yoe)
	yoe.place(x=250 , y=210)

	fee = Entry(winsignup, width=40 , textvariable = fee)
	fee.place(x=250 , y=230)

	username = Entry(winsignup, width=40, textvariable = username)
	username.place(x=250 , y=250)

	password = Entry(winsignup, width=40, textvariable = password)
	password.place(x=250 , y=270)

	very_pass= Entry(winsignup, width=40 ,show="*" , textvariable = very_pass)
	very_pass.place(x=250 , y=290)

	# button login and clear

	btn_signup = customtkinter.CTkButton(winsignup, text = "SIGN UP", command = action)
	btn_signup.place(x=200, y=340)

	# btn_login = customtkinter.CTkButton(winsignup, text = "CLEAR" , command = clear)
	# btn_login.place(x=350, y=340)

	sign_up_btn = customtkinter.CTkButton(winsignup , text="SWITCH TO LOGIN PAGE" )#command = switch )
	sign_up_btn.place(x=350 , y=20)

	winsignup.mainloop()
#---------------------------------------------------------------------------End Singup Window-----------------------------------	

#------------------------------------------------------------ Login Window -----------------------------------------

win = Tk()

# app title
win.title("Shushruta - Doctor Login Page")

# window size
win.maxsize(width=750 ,  height=750)
win.minsize(width=750 ,  height=750)


#heading label
heading = Label(win , text = "Doctor Login" , font = 'Verdana 25 bold')
heading.place(x=80 , y=150)

username = customtkinter.CTkButton(win, text= "Username:")
username.place(x=80,y=220)

userpass = customtkinter.CTkButton(win, text= "Password :")
userpass.place(x=80,y=260)

# Entry Box
username = StringVar()
password = StringVar()

userentry = Entry(win, width=40 , textvariable = username)
userentry.focus()
userentry.place(x=250 , y=223)

passentry = Entry(win, width=40, show="*" ,textvariable = password)
passentry.place(x=250 , y=260)

# button login and clear

btn_login = customtkinter.CTkButton(win, text = "LOGIN",command = login)
btn_login.place(x=200, y=293)

btn_login = customtkinter.CTkButton(win, text = "CLEAR", command = clear)
btn_login.place(x=350, y=293)

# signup button

sign_up_btn = customtkinter.CTkButton(win , text="SWITCH TO SIGN PAGE" , command = signup )
sign_up_btn.place(x=350 , y =20)

win.mainloop()

#-------------------------------------------------------------------------- End Login Window ---------------------------------------------------