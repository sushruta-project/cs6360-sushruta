import curses
from tkinter import *
import tkinter as tk
from tkinter import ttk, messagebox
import pymysql
import customtkinter

des = Tk()
des.title('Pharmacy - Add a Medicine')
des.maxsize(width=800 ,  height=800)
des.minsize(width=800 ,  height=800)		

#heading label
heading = Label(des , text = 'Add a Medicine' , font = 'Verdana 20 bold',)
heading.place(x=220 , y=50)

f=Frame(des,height=1,width=800,bg="black")
f.place(x=0,y=95)

med_id = StringVar()
count = StringVar()
price = StringVar()
	
med_id = Entry(des, width=40 , textvariable = med_id)
med_id.place(x=250 , y=135)
	
count1 = Entry(des, width=40 , textvariable = count)
count1.place(x=250 , y=165)

price = Entry(des, width=40, textvariable = price)
price.place(x=250 , y=195)

Mname = Label(des, text= "Medicine Name :" , font='Verdana 10 bold')
Mname.place(x=80,y=135)

C = Label(des, text= "Count :" , font='Verdana 10 bold')
C.place(x=80,y=165)

P = Label(des, text= " Price :" , font='Verdana 10 bold')
P.place(x=80,y=195)

btn_signup = customtkinter.CTkButton(des, text = "ADD") #command = action)
btn_signup.place(x=200, y=300)

des.mainloop()
