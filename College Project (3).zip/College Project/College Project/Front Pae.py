!pip install customtkinter

